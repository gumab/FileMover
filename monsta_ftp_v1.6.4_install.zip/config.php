<?php

# Open README file for descriptions and help.

$ftpHost = "";
$ftpPort = "21";
$ftpMode = "1";
$ftpSSL  = "0";
$ftpDir  = "";
$serverTmp = "/tmp"; // Linux
// $serverTmp = "C:\\WINDOWS\\Temp\\"; // Windows
$editableExts = "asp,ashx,asmx,aspx,asx,axd,cfm,cgi,css,html,htm,jhtml,js,php,phtml,pl,txt,xhtml";
$dateFormatUsa = 0;
$lockOutTime = 5;
$versionCheck = 1;
$showAdvOption = 1;
$showLockSess = 1;
$showHostInfo = 1;

?>